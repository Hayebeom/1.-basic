# 1.basic
// 실습 1)
