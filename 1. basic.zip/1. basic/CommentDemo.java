package basic;

/*
 * 다중 행 주석(범위주석) : /* 하고 엔터
 * 		여러 줄의 주석(코멘트)을 작성할 때 사용
 * 작성일 : 2020. 3. 9
 * 작성자 : 홍길동
 * 이메일 : hong@gmail.com
 * 내  용 : 단일 행, 다중 행 주석 연습하기
 */
public class CommentDemo {
	
	public static void main(String[] args) {
		// 단일 행 주석
		
		System.out.println("Hello, world!");
		System.out.println("Hello, world!");
		System.out.println("Hello, world!");
		System.out.println("Hello, world!");
		// 표준 출력 장치에 "Hello, world!"를 출력
		
	}
}
