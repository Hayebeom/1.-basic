package basic;

public class Hello {
	public static void main(String[] args) {
		System.out.println("안녕하세요");
		System.out.println(10*45);
		System.out.println("나는 나다");
		System.out.println(Math.PI);
	}

}

