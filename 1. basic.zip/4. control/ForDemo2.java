package control;

public class ForDemo2 {
	public static void main(String[] args) {
		/*
		1부터 까지의 합계 계산 
		*/
		
		int sum = 0;
		
		for(int i=1; i<6; i++) {
			sum += i;
		}
		
		System.out.println(sum);
	}
}
